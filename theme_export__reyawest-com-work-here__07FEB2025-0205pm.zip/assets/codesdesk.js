$(document).ready(function(){
  console.log('file is working now');
})